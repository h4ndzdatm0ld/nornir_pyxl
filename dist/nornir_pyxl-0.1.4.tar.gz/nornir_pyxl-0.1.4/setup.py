# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nornir_pyxl', 'nornir_pyxl.plugins', 'nornir_pyxl.plugins.tasks']

package_data = \
{'': ['*']}

install_requires = \
['nornir-utils>=0.1.2,<0.2.0', 'nornir>=3.0.0,<4.0.0', 'openpyxl>=3.0.5,<4.0.0']

setup_kwargs = {
    'name': 'nornir-pyxl',
    'version': '0.1.4',
    'description': 'OpenPyxl plugin for Nornir',
    'long_description': '\n# Open Pyxl plugin for [Nornir](github.com/nornir-automation/nornir)\n\n## Table of Contents\n\n- [Open Pyxl plugin for Nornir](#open-pyxl-plugin-for-nornir)\n  - [Table of Contents](#table-of-contents)\n  - [Installation](#installation)\n  - [Plugins -> Tasks](#plugins---tasks)\n  - [Examples](#examples)\n    - [Pyxl Ez Data](#pyxl-ez-data)\n    - [Example - Map Data](#example---map-data)\n\n## Installation\n\n------------\n\n```bash\npip install nornir_pyxl\n```\n\n## Plugins -> Tasks\n\n------------\n\n- **pyxl_ez_data** - Loads an XLSX file and creates a list of dictionaries. Excel file must be in a specific format.\n- **pyxl_map_data** - Loads an XLSX file and creates a list of dictionaries based on a user provided ENUM map. Allows user to specify row & column start & end.\n\n## Examples\n\n### Pyxl Ez Data\n\n------------\n\n```python\nfrom nornir_pyxl.plugins.tasks import pyxl_ez_data\nfrom nornir import InitNornir\n\nnr = InitNornir("config.yml")\n\n\ndef get_structured_data(task):\n    """Get a list of dictionaries from Excel Spreadsheet with Nornir Pyxl."""\n    data = pyxl_ez_data(task, workbook="example-workbook.xlsx", sheetname="IP_INFORMATION")\n\n    # Loop through items and access dictionaries.\n    for site_clli in data.result:\n        print(site_clli["clli"])\n\n\ndef main():\n    """Execute Tasks."""\n    nr.run(task=get_structured_data)\n\nif __name__ == "__main__"\n    main()\n```\n\n### Example - Map Data\n\n------------\n\n```python\nTODO: Add working example with enum map and row\n```\n',
    'author': 'Hugo',
    'author_email': 'hugotinoco@icloud.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/h4ndzdatm0ld/nornir_pyxl',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
